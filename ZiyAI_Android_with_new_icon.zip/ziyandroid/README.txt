Ziy AI Android 1.1
این نسخه رابط اندروید را به سرور Ziy AI وصل می‌کند.
در MainActivity.java مقدار SERVER_URL را با آدرس HTTPS سرور خودت عوض کن.
کلید OpenAI را هرگز داخل APK نگذار؛ کلید باید فقط روی سرور باشد.
سرور باید POST /api/chat را بپذیرد و JSON مثل {"text":"..."} برگرداند.
