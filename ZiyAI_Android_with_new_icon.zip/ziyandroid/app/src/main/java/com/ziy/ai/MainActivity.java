package com.ziy.ai;
import android.app.*; import android.os.*; import android.widget.*; import java.io.*; import java.net.*; import org.json.*;

public class MainActivity extends Activity {
 TextView chat; EditText input; ScrollView scroll;
 // Put YOUR deployed HTTPS Ziy AI server here.
 static final String SERVER_URL="https://ziy-ai.onrender.com/api/chat";
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  chat=findViewById(R.id.chat);input=findViewById(R.id.input);scroll=findViewById(R.id.scroll);
  findViewById(R.id.send).setOnClickListener(v->send());
 }
 void send(){String m=input.getText().toString().trim();if(m.isEmpty())return; chat.append("\n\nشما: "+m);input.setText("");
  chat.append("\n\nZiy AI: در حال فکر کردن... ⏳"); scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
  new Thread(()->{try{
    URL u=new URL(SERVER_URL);HttpURLConnection c=(HttpURLConnection)u.openConnection();
    c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/json");c.setDoOutput(true);
    JSONObject o=new JSONObject();o.put("message",m);
    OutputStream os=c.getOutputStream();os.write(o.toString().getBytes("UTF-8"));os.close();
    BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null)s.append(line);
    JSONObject ans=new JSONObject(s.toString());String text=ans.optString("text","پاسخی دریافت نشد.");
    runOnUiThread(()->{chat.append("\n"+text);scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));});
   }catch(Exception e){runOnUiThread(()->chat.append("\nاتصال برقرار نشد. آدرس سرور را در MainActivity تنظیم کن."));}
  }).start();
 }
}